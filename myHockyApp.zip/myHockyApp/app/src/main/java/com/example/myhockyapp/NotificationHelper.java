package com.example.myhockyapp;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class NotificationHelper {
    private static final String CHANNEL_ID = "HockeyMatchChannel";
    private static final String CHANNEL_NAME = "Hockey Match Notifications";
    private static final String TAG = "NotificationHelper";

    public static void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    public static void scheduleMatchNotification(Context context, int matchId, String team1, String team2, String date, String time) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
            Calendar matchDate = Calendar.getInstance();
            matchDate.setTime(dateFormat.parse(date + " " + time));
            Calendar now = Calendar.getInstance();
            long delay = 30 * 1000; // 30 seconds for testing

            if (delay > 0) {
                Data inputData = new Data.Builder()
                        .putInt("matchId", matchId)
                        .putString("team1", team1)
                        .putString("team2", team2)
                        .putString("date", date)
                        .putString("time", time)
                        .build();

                OneTimeWorkRequest notificationWork = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                        .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                        .setInputData(inputData)
                        .build();

                WorkManager.getInstance(context).enqueue(notificationWork);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void showNotification(Context context, int matchId, String team1, String team2, String date, String time) {
        Intent intent = new Intent(context, MatchActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, matchId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.icon_notification)
                .setContentTitle("Upcoming Hockey Match (ID: " + matchId + ")")
                .setContentText("Match between " + team1 + " and " + team2 + " scheduled for " + date + " at " + time)
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText("Match ID: " + matchId + "\nTeams: " + team1 + " vs " + team2 + "\nDate: " + date + "\nTime: " + time))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(matchId, builder.build());
    }
}