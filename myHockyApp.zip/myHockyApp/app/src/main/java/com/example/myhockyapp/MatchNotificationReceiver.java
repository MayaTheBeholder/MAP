package com.example.myhockyapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class MatchNotificationReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int matchId = intent.getIntExtra("matchId", 0);
        String team1 = intent.getStringExtra("team1");
        String team2 = intent.getStringExtra("team2");
        String date = intent.getStringExtra("date");
        String time = intent.getStringExtra("time");

        NotificationHelper.showNotification(context, matchId, team1, team2, date, time);
    }
}