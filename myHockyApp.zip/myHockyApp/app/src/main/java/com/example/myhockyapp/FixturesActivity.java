package com.example.myhockyapp;

  import android.database.Cursor;
  import android.os.Bundle;
  import android.widget.ArrayAdapter;
  import android.widget.ListView;
  import androidx.appcompat.app.AppCompatActivity;
  import androidx.appcompat.widget.Toolbar;
  import java.util.ArrayList;

  public class FixturesActivity extends AppCompatActivity {
      private DatabaseHelper dbHelper;
      private ListView fixturesList;

      @Override
      protected void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          setContentView(R.layout.activity_fixtures);

          Toolbar toolbar = findViewById(R.id.toolbar);
          setSupportActionBar(toolbar);
          toolbar.setTitle("");

          dbHelper = new DatabaseHelper(this);
          fixturesList = findViewById(R.id.fixtures_list);

          loadFixtures();
      }

      private void loadFixtures() {
          ArrayList<String> fixtures = new ArrayList<>();
          Cursor cursor = dbHelper.getFixtures();
          if (cursor.moveToFirst()) {
              do {
                  int matchId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                  String team1Name = cursor.getString(cursor.getColumnIndexOrThrow("team1_name"));
                  String team2Name = cursor.getString(cursor.getColumnIndexOrThrow("team2_name"));
                  String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                  String time = cursor.getString(cursor.getColumnIndexOrThrow("time"));
                  fixtures.add("Match ID: " + matchId + "\n" +
                          team1Name + " vs " + team2Name + "\n" +
                          "Date: " + date + " " + time);
              } while (cursor.moveToNext());
          }
          cursor.close();

          ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                  android.R.layout.simple_list_item_1, fixtures);
          fixturesList.setAdapter(adapter);
      }
  }