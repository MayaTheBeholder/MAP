package com.example.myhockyapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = "DatabaseHelper";
    private static final String DATABASE_NAME = "HockeyManager.db";
    private static final int DATABASE_VERSION = 4;
    private static final String TABLE_TEAMS = "teams";
    private static final String TABLE_PLAYERS = "players";
    private static final String TABLE_MATCHES = "matches";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TEAM_NAME = "team_name";
    private static final String COLUMN_PLAYER_NAME = "player_name";
    private static final String COLUMN_TEAM_ID = "team_id";
    private static final String COLUMN_MATCH_DATE = "match_date";
    private static final String COLUMN_MATCH_TIME = "match_time";
    private static final String COLUMN_TEAM1_ID = "team1_id";
    private static final String COLUMN_TEAM2_ID = "team2_id";
    private static final String COLUMN_TEAM1_SCORE = "team1_score";
    private static final String COLUMN_TEAM2_SCORE = "team2_score";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d(TAG, "DatabaseHelper initialized with version " + DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            Log.d(TAG, "Creating database tables");
            String createTeamsTable = "CREATE TABLE " + TABLE_TEAMS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_TEAM_NAME + " TEXT NOT NULL)";
            db.execSQL(createTeamsTable);
            Log.d(TAG, "Created teams table");

            String createPlayersTable = "CREATE TABLE " + TABLE_PLAYERS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_PLAYER_NAME + " TEXT NOT NULL, " +
                    COLUMN_TEAM_ID + " INTEGER, " +
                    "FOREIGN KEY(" + COLUMN_TEAM_ID + ") REFERENCES " + TABLE_TEAMS + "(" + COLUMN_ID + "))";
            db.execSQL(createPlayersTable);
            Log.d(TAG, "Created players table");

            String createMatchesTable = "CREATE TABLE " + TABLE_MATCHES + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_TEAM1_ID + " INTEGER, " +
                    COLUMN_TEAM2_ID + " INTEGER, " +
                    COLUMN_MATCH_DATE + " TEXT NOT NULL, " +
                    COLUMN_MATCH_TIME + " TEXT NOT NULL, " +
                    COLUMN_TEAM1_SCORE + " INTEGER, " +
                    COLUMN_TEAM2_SCORE + " INTEGER, " +
                    "FOREIGN KEY(" + COLUMN_TEAM1_ID + ") REFERENCES " + TABLE_TEAMS + "(" + COLUMN_ID + "), " +
                    "FOREIGN KEY(" + COLUMN_TEAM2_ID + ") REFERENCES " + TABLE_TEAMS + "(" + COLUMN_ID + "))";
            db.execSQL(createMatchesTable);
            Log.d(TAG, "Created matches table");
        } catch (SQLiteException e) {
            Log.e(TAG, "Error creating tables: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            Log.d(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion);
            if (oldVersion < 4) {
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_MATCHES);
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_PLAYERS);
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_TEAMS);
                Log.d(TAG, "Dropped existing tables");
                onCreate(db);
            }
        } catch (SQLiteException e) {
            Log.e(TAG, "Error upgrading database: " + e.getMessage());
            throw e;
        }
    }

    public boolean isTeamsTableAccessible() {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            cursor = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", new String[]{TABLE_TEAMS});
            boolean tableExists = cursor.moveToFirst();
            if (tableExists) {
                cursor = db.rawQuery("PRAGMA table_info(" + TABLE_TEAMS + ")", null);
                boolean hasTeamNameColumn = false;
                if (cursor.moveToFirst()) {
                    do {
                        String columnName = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                        if (COLUMN_TEAM_NAME.equals(columnName)) {
                            hasTeamNameColumn = true;
                            break;
                        }
                    } while (cursor.moveToNext());
                }
                Log.d(TAG, "Teams table exists: " + tableExists + ", has team_name column: " + hasTeamNameColumn);
                return tableExists && hasTeamNameColumn;
            }
            return false;
        } catch (SQLiteException e) {
            Log.e(TAG, "Error checking teams table: " + e.getMessage());
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
    }

    public boolean addTeam(String teamName) {
        SQLiteDatabase db = null;
        try {
            if (!isTeamsTableAccessible()) {
                Log.e(TAG, "Teams table is not accessible or has incorrect schema");
                return false;
            }
            db = this.getWritableDatabase();
            if (!db.isOpen()) {
                Log.e(TAG, "Database is not open for writing");
                return false;
            }
            ContentValues values = new ContentValues();
            values.put(COLUMN_TEAM_NAME, teamName);
            long result = db.insert(TABLE_TEAMS, null, values);
            Log.d(TAG, "Insert team '" + teamName + "' result: " + result);
            return result != -1;
        } catch (SQLiteException e) {
            Log.e(TAG, "Error inserting team '" + teamName + "': " + e.getMessage());
            return false;
        } catch (Exception e) {
            Log.e(TAG, "Unexpected error inserting team '" + teamName + "': " + e.getMessage());
            return false;
        } finally {
            if (db != null && db.isOpen()) {
                db.close();
                Log.d(TAG, "Database closed after addTeam");
            }
        }
    }

    public List<String> getAllTeams() {
        List<String> teams = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            cursor = db.rawQuery("SELECT " + COLUMN_TEAM_NAME + " FROM " + TABLE_TEAMS, null);
            if (cursor.moveToFirst()) {
                do {
                    teams.add(cursor.getString(0));
                } while (cursor.moveToNext());
            }
            Log.d(TAG, "Retrieved " + teams.size() + " teams");
        } catch (SQLiteException e) {
            Log.e(TAG, "Error retrieving teams: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
        return teams;
    }

    public boolean addPlayer(String playerName, int teamId) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_PLAYER_NAME, playerName);
            values.put(COLUMN_TEAM_ID, teamId);
            long result = db.insert(TABLE_PLAYERS, null, values);
            Log.d(TAG, "Insert player '" + playerName + "' result: " + result);
            return result != -1;
        } catch (SQLiteException e) {
            Log.e(TAG, "Error inserting player: " + e.getMessage());
            return false;
        } finally {
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
    }

    public List<String> getPlayersByTeam(int teamId) {
        List<String> players = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            cursor = db.rawQuery("SELECT " + COLUMN_PLAYER_NAME + " FROM " + TABLE_PLAYERS +
                    " WHERE " + COLUMN_TEAM_ID + " = ?", new String[]{String.valueOf(teamId)});
            if (cursor.moveToFirst()) {
                do {
                    players.add(cursor.getString(0));
                } while (cursor.moveToNext());
            }
            Log.d(TAG, "Retrieved " + players.size() + " players for team ID " + teamId);
        } catch (SQLiteException e) {
            Log.e(TAG, "Error retrieving players: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
        return players;
    }

    public int getTeamIdByName(String teamName) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            cursor = db.rawQuery("SELECT " + COLUMN_ID + " FROM " + TABLE_TEAMS +
                    " WHERE " + COLUMN_TEAM_NAME + " = ?", new String[]{teamName});
            if (cursor.moveToFirst()) {
                int teamId = cursor.getInt(0);
                Log.d(TAG, "Found team ID " + teamId + " for team '" + teamName + "'");
                return teamId;
            }
            Log.w(TAG, "Team '" + teamName + "' not found");
            return -1;
        } catch (SQLiteException e) {
            Log.e(TAG, "Error retrieving team ID for '" + teamName + "': " + e.getMessage());
            return -1;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
    }

    public boolean addMatch(int team1Id, int team2Id, String date, String time, Integer team1Score, Integer team2Score) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_TEAM1_ID, team1Id);
            values.put(COLUMN_TEAM2_ID, team2Id);
            values.put(COLUMN_MATCH_DATE, date);
            values.put(COLUMN_MATCH_TIME, time);
            if (team1Score != null) values.put(COLUMN_TEAM1_SCORE, team1Score);
            if (team2Score != null) values.put(COLUMN_TEAM2_SCORE, team2Score);
            long result = db.insert(TABLE_MATCHES, null, values);
            Log.d(TAG, "Insert match between team IDs " + team1Id + " and " + team2Id + " result: " + result);
            return result != -1;
        } catch (SQLiteException e) {
            Log.e(TAG, "Error inserting match: " + e.getMessage());
            return false;
        } finally {
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
    }

    public List<String> getAllMatches() {
        List<String> matches = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            String query = "SELECT t1." + COLUMN_TEAM_NAME + " AS team1, t2." + COLUMN_TEAM_NAME + " AS team2, " +
                    TABLE_MATCHES + "." + COLUMN_MATCH_DATE + ", " + TABLE_MATCHES + "." + COLUMN_MATCH_TIME + ", " +
                    TABLE_MATCHES + "." + COLUMN_TEAM1_SCORE + ", " + TABLE_MATCHES + "." + COLUMN_TEAM2_SCORE +
                    " FROM " + TABLE_MATCHES +
                    " JOIN " + TABLE_TEAMS + " t1 ON " + TABLE_MATCHES + "." + COLUMN_TEAM1_ID + " = t1." + COLUMN_ID +
                    " JOIN " + TABLE_TEAMS + " t2 ON " + TABLE_MATCHES + "." + COLUMN_TEAM2_ID + " = t2." + COLUMN_ID;
            cursor = db.rawQuery(query, null);
            if (cursor.moveToFirst()) {
                do {
                    String team1 = cursor.getString(0);
                    String team2 = cursor.getString(1);
                    String date = cursor.getString(2);
                    String time = cursor.getString(3);
                    String score = (cursor.isNull(4) || cursor.isNull(5)) ? " (No score)" :
                            " (" + cursor.getInt(4) + " - " + cursor.getInt(5) + ")";
                    String match = team1 + " vs " + team2 + " on " + date + " at " + time + score;
                    matches.add(match);
                } while (cursor.moveToNext());
            }
            Log.d(TAG, "Retrieved " + matches.size() + " matches");
        } catch (SQLiteException e) {
            Log.e(TAG, "Error retrieving matches: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
        return matches;
    }

    public List<TeamStanding> getStandings() {
        List<TeamStanding> standings = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            cursor = db.rawQuery("SELECT " + COLUMN_ID + ", " + COLUMN_TEAM_NAME + " FROM " + TABLE_TEAMS, null);
            if (cursor.moveToFirst()) {
                do {
                    int teamId = cursor.getInt(0);
                    String teamName = cursor.getString(1);
                    standings.add(new TeamStanding(teamId, teamName));
                } while (cursor.moveToNext());
            }
            cursor.close();

            String query = "SELECT " + COLUMN_TEAM1_ID + ", " + COLUMN_TEAM2_ID + ", " +
                    COLUMN_TEAM1_SCORE + ", " + COLUMN_TEAM2_SCORE +
                    " FROM " + TABLE_MATCHES +
                    " WHERE " + COLUMN_TEAM1_SCORE + " IS NOT NULL AND " + COLUMN_TEAM2_SCORE + " IS NOT NULL";
            cursor = db.rawQuery(query, null);
            if (cursor.moveToFirst()) {
                do {
                    int team1Id = cursor.getInt(0);
                    int team2Id = cursor.getInt(1);
                    int team1Score = cursor.getInt(2);
                    int team2Score = cursor.getInt(3);

                    for (TeamStanding standing : standings) {
                        if (standing.teamId == team1Id) {
                            standing.matchesPlayed++;
                            standing.goalsScored += team1Score;
                            standing.goalsConceded += team2Score;
                            if (team1Score > team2Score) {
                                standing.wins++;
                                standing.points += 3;
                            } else if (team1Score == team2Score) {
                                standing.draws++;
                                standing.points += 1;
                            } else {
                                standing.losses++;
                            }
                        } else if (standing.teamId == team2Id) {
                            standing.matchesPlayed++;
                            standing.goalsScored += team2Score;
                            standing.goalsConceded += team1Score;
                            if (team2Score > team1Score) {
                                standing.wins++;
                                standing.points += 3;
                            } else if (team2Score == team1Score) {
                                standing.draws++;
                                standing.points += 1;
                            } else {
                                standing.losses++;
                            }
                        }
                    }
                } while (cursor.moveToNext());
            }
            standings.sort((a, b) -> {
                if (b.points != a.points) {
                    return b.points - a.points;
                }
                return (b.goalsScored - b.goalsConceded) - (a.goalsScored - a.goalsConceded);
            });
            Log.d(TAG, "Retrieved standings for " + standings.size() + " teams");
        } catch (SQLiteException e) {
            Log.e(TAG, "Error retrieving standings: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
        return standings;
    }

    public List<MatchNotification> getUpcomingMatches() {
        List<MatchNotification> upcomingMatches = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            String query = "SELECT t1." + COLUMN_TEAM_NAME + " AS team1, t2." + COLUMN_TEAM_NAME + " AS team2, " +
                    TABLE_MATCHES + "." + COLUMN_MATCH_DATE + ", " + TABLE_MATCHES + "." + COLUMN_MATCH_TIME + ", " +
                    TABLE_MATCHES + "." + COLUMN_ID +
                    " FROM " + TABLE_MATCHES +
                    " JOIN " + TABLE_TEAMS + " t1 ON " + TABLE_MATCHES + "." + COLUMN_TEAM1_ID + " = t1." + COLUMN_ID +
                    " JOIN " + TABLE_TEAMS + " t2 ON " + TABLE_MATCHES + "." + COLUMN_TEAM2_ID + " = t2." + COLUMN_ID;
            cursor = db.rawQuery(query, null);
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
            Calendar now = Calendar.getInstance();
            Calendar future = Calendar.getInstance();
            future.add(Calendar.DAY_OF_YEAR, 7);

            if (cursor.moveToFirst()) {
                do {
                    String team1 = cursor.getString(0);
                    String team2 = cursor.getString(1);
                    String date = cursor.getString(2);
                    String time = cursor.getString(3);
                    int matchId = cursor.getInt(4);
                    try {
                        Calendar matchDate = Calendar.getInstance();
                        matchDate.setTime(dateFormat.parse(date + " " + time));
                        if (matchDate.after(now) && matchDate.before(future)) {
                            upcomingMatches.add(new MatchNotification(matchId, team1, team2, date, time));
                            Log.d(TAG, "Found upcoming match: " + team1 + " vs " + team2 + " on " + date + " " + time);
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error parsing date/time for match: " + e.getMessage());
                    }
                } while (cursor.moveToNext());
            }
            Log.d(TAG, "Retrieved " + upcomingMatches.size() + " upcoming matches");
        } catch (SQLiteException e) {
            Log.e(TAG, "Error retrieving upcoming matches: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null && db.isOpen()) {
                db.close();
            }
        }
        return upcomingMatches;
    }

    public static class TeamStanding {
        public int teamId;
        public String teamName;
        public int matchesPlayed;
        public int wins;
        public int draws;
        public int losses;
        public int goalsScored;
        public int goalsConceded;
        public int points;

        public TeamStanding(int teamId, String teamName) {
            this.teamId = teamId;
            this.teamName = teamName;
            this.matchesPlayed = 0;
            this.wins = 0;
            this.draws = 0;
            this.losses = 0;
            this.goalsScored = 0;
            this.goalsConceded = 0;
            this.points = 0;
        }
    }

    public static class MatchNotification {
        public int matchId;
        public String team1;
        public String team2;
        public String date;
        public String time;

        public MatchNotification(int matchId, String team1, String team2, String date, String time) {
            this.matchId = matchId;
            this.team1 = team1;
            this.team2 = team2;
            this.date = date;
            this.time = time;
        }
    }
}