package com.example.myhockyapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "hockey.db";
    private static final int DATABASE_VERSION = 4; // Incremented for getFixtures and getMatchHistory

    private static final String TABLE_TEAMS = "teams";
    private static final String TABLE_PLAYERS = "players";
    private static final String TABLE_MATCHES = "matches";

    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_NUMBER = "number";
    private static final String COLUMN_TEAM_ID = "team_id";
    private static final String COLUMN_TEAM1_ID = "team1_id";
    private static final String COLUMN_TEAM2_ID = "team2_id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_TIME = "time";
    private static final String COLUMN_TEAM1_SCORE = "team1_score";
    private static final String COLUMN_TEAM2_SCORE = "team2_score";

    private static final String CREATE_TABLE_TEAMS = "CREATE TABLE " + TABLE_TEAMS +
            "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_NAME + " TEXT)";

    private static final String CREATE_TABLE_PLAYERS = "CREATE TABLE " + TABLE_PLAYERS +
            "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_NAME + " TEXT, " +
            COLUMN_NUMBER + " INTEGER, " +
            COLUMN_TEAM_ID + " INTEGER)";

    private static final String CREATE_TABLE_MATCHES = "CREATE TABLE " + TABLE_MATCHES +
            "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_TEAM1_ID + " INTEGER, " +
            COLUMN_TEAM2_ID + " INTEGER, " +
            COLUMN_DATE + " TEXT, " +
            COLUMN_TIME + " TEXT, " +
            COLUMN_TEAM1_SCORE + " INTEGER, " +
            COLUMN_TEAM2_SCORE + " INTEGER)";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_TEAMS);
        db.execSQL(CREATE_TABLE_PLAYERS);
        db.execSQL(CREATE_TABLE_MATCHES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_PLAYERS + " ADD COLUMN " + COLUMN_NUMBER + " INTEGER");
        }
        if (oldVersion < 3) {
            db.execSQL(CREATE_TABLE_MATCHES);
        }
        // Version 4: No schema changes, added getFixtures and getMatchHistory
    }

    public boolean addTeam(String teamName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, teamName);
        long result = db.insert(TABLE_TEAMS, null, values);
        db.close();
        return result != -1;
    }

    public boolean addPlayer(String name, int number, int teamId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_NUMBER, number);
        values.put(COLUMN_TEAM_ID, teamId);
        long result = db.insert(TABLE_PLAYERS, null, values);
        db.close();
        return result != -1;
    }

    public boolean addMatch(int team1Id, int team2Id, String date, String time, int team1Score, int team2Score) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TEAM1_ID, team1Id);
        values.put(COLUMN_TEAM2_ID, team2Id);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_TIME, time);
        values.put(COLUMN_TEAM1_SCORE, team1Score);
        values.put(COLUMN_TEAM2_SCORE, team2Score);
        long result = db.insert(TABLE_MATCHES, null, values);
        db.close();
        return result != -1;
    }

    public List<String> getAllTeams() {
        List<String> teams = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_NAME + " FROM " + TABLE_TEAMS, null);
        if (cursor.moveToFirst()) {
            do {
                teams.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return teams;
    }

    public List<String> getAllPlayers() {
        List<String> players = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_NAME + ", " + COLUMN_NUMBER + " FROM " + TABLE_PLAYERS, null);
        if (cursor.moveToFirst()) {
            do {
                String player = cursor.getString(0) + " #" + cursor.getInt(1);
                players.add(player);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return players;
    }

    public int getTeamId(String teamName) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_ID + " FROM " + TABLE_TEAMS +
                " WHERE " + COLUMN_NAME + " = ?", new String[]{teamName});
        int teamId = -1;
        if (cursor.moveToFirst()) {
            teamId = cursor.getInt(0);
        }
        cursor.close();
        db.close();
        return teamId;
    }

    public Cursor getFixtures() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT m." + COLUMN_ID + ", t1." + COLUMN_NAME + " AS team1_name, t2." + COLUMN_NAME + " AS team2_name, " +
                "m." + COLUMN_DATE + ", m." + COLUMN_TIME + " " +
                "FROM " + TABLE_MATCHES + " m " +
                "JOIN " + TABLE_TEAMS + " t1 ON m." + COLUMN_TEAM1_ID + " = t1." + COLUMN_ID + " " +
                "JOIN " + TABLE_TEAMS + " t2 ON m." + COLUMN_TEAM2_ID + " = t2." + COLUMN_ID + " " +
                "WHERE m." + COLUMN_DATE + " || ' ' || m." + COLUMN_TIME + " > datetime('now', 'localtime')";
        return db.rawQuery(query, null);
    }

    public Cursor getMatchHistory() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT m." + COLUMN_ID + ", t1." + COLUMN_NAME + " AS team1_name, t2." + COLUMN_NAME + " AS team2_name, " +
                "m." + COLUMN_DATE + ", m." + COLUMN_TIME + ", m." + COLUMN_TEAM1_SCORE + ", m." + COLUMN_TEAM2_SCORE + " " +
                "FROM " + TABLE_MATCHES + " m " +
                "JOIN " + TABLE_TEAMS + " t1 ON m." + COLUMN_TEAM1_ID + " = t1." + COLUMN_ID + " " +
                "JOIN " + TABLE_TEAMS + " t2 ON m." + COLUMN_TEAM2_ID + " = t2." + COLUMN_ID + " " +
                "WHERE m." + COLUMN_DATE + " || ' ' || m." + COLUMN_TIME + " <= datetime('now', 'localtime')";
        return db.rawQuery(query, null);
    }

    public List<TeamStanding> getStandings() {
        List<TeamStanding> standings = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Get all teams
        Cursor teamCursor = db.rawQuery("SELECT " + COLUMN_ID + ", " + COLUMN_NAME + " FROM " + TABLE_TEAMS, null);
        if (teamCursor.moveToFirst()) {
            do {
                int teamId = teamCursor.getInt(0);
                String teamName = teamCursor.getString(1);
                TeamStanding standing = new TeamStanding();
                standing.teamName = teamName;
                standing.matchesPlayed = 0;
                standing.wins = 0;
                standing.draws = 0;
                standing.losses = 0;
                standing.goalsScored = 0;
                standing.goalsConceded = 0;
                standing.points = 0;

                // Calculate stats from matches
                Cursor matchCursor = db.rawQuery("SELECT " + COLUMN_TEAM1_ID + ", " + COLUMN_TEAM2_ID + ", " +
                                COLUMN_TEAM1_SCORE + ", " + COLUMN_TEAM2_SCORE + " FROM " + TABLE_MATCHES +
                                " WHERE " + COLUMN_TEAM1_ID + " = ? OR " + COLUMN_TEAM2_ID + " = ?",
                        new String[]{String.valueOf(teamId), String.valueOf(teamId)});
                if (matchCursor.moveToFirst()) {
                    do {
                        int team1Id = matchCursor.getInt(0);
                        int team2Id = matchCursor.getInt(1);
                        int team1Score = matchCursor.getInt(2);
                        int team2Score = matchCursor.getInt(3);

                        standing.matchesPlayed++;
                        if (teamId == team1Id) {
                            standing.goalsScored += team1Score;
                            standing.goalsConceded += team2Score;
                            if (team1Score > team2Score) {
                                standing.wins++;
                                standing.points += 3;
                            } else if (team1Score == team2Score) {
                                standing.draws++;
                                standing.points += 1;
                            } else {
                                standing.losses++;
                            }
                        } else {
                            standing.goalsScored += team2Score;
                            standing.goalsConceded += team1Score;
                            if (team2Score > team1Score) {
                                standing.wins++;
                                standing.points += 3;
                            } else if (team2Score == team1Score) {
                                standing.draws++;
                                standing.points += 1;
                            } else {
                                standing.losses++;
                            }
                        }
                    } while (matchCursor.moveToNext());
                }
                matchCursor.close();
                standings.add(standing);
            } while (teamCursor.moveToNext());
        }
        teamCursor.close();
        db.close();
        return standings;
    }

    public static class TeamStanding {
        public String teamName;
        public int matchesPlayed;
        public int wins;
        public int draws;
        public int losses;
        public int goalsScored;
        public int goalsConceded;
        public int points;
    }
}