package com.example.myhockyapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class PlayerActivity extends AppCompatActivity {
    private EditText playerNameInput, playerNumberInput;
    private Spinner teamSpinner;
    private Button addPlayerButton;
    private TextView playerListText;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        playerNameInput = findViewById(R.id.player_name_input);
        playerNumberInput = findViewById(R.id.player_number_input);
        teamSpinner = findViewById(R.id.team_spinner);
        addPlayerButton = findViewById(R.id.add_player_button);
        playerListText = findViewById(R.id.player_list_text);
        dbHelper = new DatabaseHelper(this);

        // Populate team spinner
        List<String> teams = dbHelper.getAllTeams();
        if (teams.isEmpty()) {
            teams.add("No teams available");
            addPlayerButton.setEnabled(false);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, teams);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        teamSpinner.setAdapter(adapter);

        addPlayerButton.setOnClickListener(v -> {
            String playerName = playerNameInput.getText().toString().trim();
            String numberStr = playerNumberInput.getText().toString().trim();
            String selectedTeam = teamSpinner.getSelectedItem().toString();

            if (playerName.isEmpty()) {
                Toast.makeText(this, "Enter player name", Toast.LENGTH_SHORT).show();
                return;
            }
            if (numberStr.isEmpty()) {
                Toast.makeText(this, "Enter player number", Toast.LENGTH_SHORT).show();
                return;
            }
            if (selectedTeam.equals("No teams available")) {
                Toast.makeText(this, "Add a team first", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int number = Integer.parseInt(numberStr);
                int teamId = dbHelper.getTeamId(selectedTeam);
                if (dbHelper.addPlayer(playerName, number, teamId)) {
                    playerNameInput.setText("");
                    playerNumberInput.setText("");
                    Toast.makeText(this, "Player " + playerName + " #" + number + " added", Toast.LENGTH_SHORT).show();
                    updatePlayerList();
                } else {
                    Toast.makeText(this, "Failed to add player", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid number format", Toast.LENGTH_SHORT).show();
            }
        });

        updatePlayerList();
    }

    private void updatePlayerList() {
        List<String> players = dbHelper.getAllPlayers();
        if (players.isEmpty()) {
            playerListText.setText("No players available");
        } else {
            StringBuilder playerList = new StringBuilder();
            for (String player : players) {
                playerList.append(player).append("\n");
            }
            playerListText.setText(playerList.toString());
        }
    }
}