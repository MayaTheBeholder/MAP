package com.example.myhockyapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class PlayerActivity extends AppCompatActivity {
    private EditText playerNameInput;
    private Spinner teamSpinner;
    private Button addPlayerButton, viewPlayersButton;
    private TextView playerListText;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        // Initialize UI components
        playerNameInput = findViewById(R.id.player_name_input);
        teamSpinner = findViewById(R.id.team_spinner);
        addPlayerButton = findViewById(R.id.add_player_button);
        viewPlayersButton = findViewById(R.id.view_players_button);
        playerListText = findViewById(R.id.player_list_text);

        // Initialize database
        dbHelper = new DatabaseHelper(this);

        // Populate team spinner
        List<String> teams = dbHelper.getAllTeams();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, teams);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        teamSpinner.setAdapter(adapter);

        // Add Player button click listener
        addPlayerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String playerName = playerNameInput.getText().toString().trim();
                String selectedTeam = teamSpinner.getSelectedItem() != null ?
                        teamSpinner.getSelectedItem().toString() : "";
                if (playerName.isEmpty() || selectedTeam.isEmpty()) {
                    Toast.makeText(PlayerActivity.this, "Enter player name and select team",
                            Toast.LENGTH_SHORT).show();
                } else {
                    int teamId = dbHelper.getTeamIdByName(selectedTeam);
                    if (teamId != -1) {
                        boolean isAdded = dbHelper.addPlayer(playerName, teamId);
                        if (isAdded) {
                            Toast.makeText(PlayerActivity.this, "Player added",
                                    Toast.LENGTH_SHORT).show();
                            playerNameInput.setText("");
                        } else {
                            Toast.makeText(PlayerActivity.this, "Failed to add player",
                                    Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(PlayerActivity.this, "Team not found",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // View Players button click listener
        viewPlayersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectedTeam = teamSpinner.getSelectedItem() != null ?
                        teamSpinner.getSelectedItem().toString() : "";
                if (selectedTeam.isEmpty()) {
                    playerListText.setText("Select a team to view players");
                } else {
                    int teamId = dbHelper.getTeamIdByName(selectedTeam);
                    if (teamId != -1) {
                        List<String> players = dbHelper.getPlayersByTeam(teamId);
                        if (players.isEmpty()) {
                            playerListText.setText("No players for this team");
                        } else {
                            StringBuilder playerList = new StringBuilder();
                            for (String player : players) {
                                playerList.append(player).append("\n");
                            }
                            playerListText.setText(playerList.toString());
                        }
                    } else {
                        playerListText.setText("Team not found");
                    }
                }
            }
        });
    }
}