package com.example.myhockyapp;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class StandingsActivity extends AppCompatActivity {
    private RecyclerView standingsRecyclerView;
    private StandingsAdapter standingsAdapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_standings);

        standingsRecyclerView = findViewById(R.id.standings_recycler_view);
        standingsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DatabaseHelper(this);
        loadStandings();
    }

    private void loadStandings() {
        try {
            List<DatabaseHelper.TeamStanding> standings = dbHelper.getStandings();
            if (standings.isEmpty()) {
                Toast.makeText(this, "No teams or matches available", Toast.LENGTH_SHORT).show();
            }
            standingsAdapter = new StandingsAdapter(standings);
            standingsRecyclerView.setAdapter(standingsAdapter);
        } catch (Exception e) {
            Toast.makeText(this, "Error loading standings: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}