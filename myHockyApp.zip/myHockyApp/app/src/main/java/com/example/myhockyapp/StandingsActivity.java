package com.example.myhockyapp;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class StandingsActivity extends AppCompatActivity {
    private static final String TAG = "StandingsActivity";
    private RecyclerView standingsRecyclerView;
    private StandingsAdapter standingsAdapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_standings);

        try {
            standingsRecyclerView = findViewById(R.id.standings_recycler_view);
            standingsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            dbHelper = new DatabaseHelper(this);

            List<DatabaseHelper.TeamStanding> standings = dbHelper.getStandings();
            if (standings.isEmpty()) {
                Toast.makeText(this, "No standings available", Toast.LENGTH_SHORT).show();
            }
            standingsAdapter = new StandingsAdapter(standings);
            standingsRecyclerView.setAdapter(standingsAdapter);
        } catch (Exception e) {
            Log.e(TAG, "Error loading standings: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading standings", Toast.LENGTH_LONG).show();
        }
    }
}