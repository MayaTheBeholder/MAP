package com.example.myhockyapp;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;
import java.util.List;

public class MatchActivity extends AppCompatActivity {
    private static final String TAG = "MatchActivity";
    private Spinner team1Spinner, team2Spinner;
    private Button selectDateButton, selectTimeButton, addMatchButton, viewMatchesButton;
    private TextView dateText, timeText, matchListText;
    private EditText team1ScoreInput, team2ScoreInput;
    private DatabaseHelper dbHelper;
    private String selectedDate = "", selectedTime = "";
    private String selectedTeam1 = "", selectedTeam2 = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_match);

        // Initialize notification channel
        NotificationHelper.createNotificationChannel(this);

        // Initialize UI components
        try {
            team1Spinner = findViewById(R.id.team1_spinner);
            team2Spinner = findViewById(R.id.team2_spinner);
            selectDateButton = findViewById(R.id.select_date_button);
            selectTimeButton = findViewById(R.id.select_time_button);
            addMatchButton = findViewById(R.id.add_match_button);
            viewMatchesButton = findViewById(R.id.view_matches_button);
            dateText = findViewById(R.id.date_text);
            timeText = findViewById(R.id.time_text);
            team1ScoreInput = findViewById(R.id.team1_score_input);
            team2ScoreInput = findViewById(R.id.team2_score_input);
            matchListText = findViewById(R.id.match_list_text);
        } catch (Exception e) {
            Log.e(TAG, "Error initializing UI components: " + e.getMessage());
            Toast.makeText(this, "UI initialization failed", Toast.LENGTH_LONG).show();
            return;
        }

        // Initialize database
        try {
            dbHelper = new DatabaseHelper(this);
        } catch (Exception e) {
            Log.e(TAG, "Error initializing database: " + e.getMessage());
            Toast.makeText(this, "Database initialization failed", Toast.LENGTH_LONG).show();
            return;
        }

        // Populate team spinners
        List<String> teams = dbHelper.getAllTeams();
        Log.d(TAG, "Retrieved " + teams.size() + " teams: " + teams);
        if (teams.isEmpty()) {
            Toast.makeText(this, "No teams available. Please add teams first.", Toast.LENGTH_LONG).show();
            team1Spinner.setEnabled(false);
            team2Spinner.setEnabled(false);
            addMatchButton.setEnabled(false);
        } else {
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, teams);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            team1Spinner.setAdapter(adapter);
            team2Spinner.setAdapter(adapter);
            team1Spinner.setEnabled(true);
            team2Spinner.setEnabled(true);
            addMatchButton.setEnabled(true);

            team1Spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    selectedTeam1 = teams.get(position);
                    Log.d(TAG, "Team 1 selected: " + selectedTeam1);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    selectedTeam1 = "";
                    Log.d(TAG, "No team selected for Team 1");
                }
            });

            team2Spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    selectedTeam2 = teams.get(position);
                    Log.d(TAG, "Team 2 selected: " + selectedTeam2);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    selectedTeam2 = "";
                    Log.d(TAG, "No team selected for Team 2");
                }
            });
        }

        // Date picker button
        selectDateButton.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(MatchActivity.this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {
                        selectedDate = selectedYear + "-" + (selectedMonth + 1) + "-" + selectedDay;
                        dateText.setText(selectedDate);
                        Log.d(TAG, "Selected date: " + selectedDate);
                    }, year, month, day);
            datePickerDialog.show();
        });

        // Time picker button
        selectTimeButton.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);
            TimePickerDialog timePickerDialog = new TimePickerDialog(MatchActivity.this,
                    (view, selectedHour, selectedMinute) -> {
                        selectedTime = String.format("%02d:%02d", selectedHour, selectedMinute);
                        timeText.setText(selectedTime);
                        Log.d(TAG, "Selected time: " + selectedTime);
                    }, hour, minute, true);
            timePickerDialog.show();
        });

        // Add Match button
        addMatchButton.setOnClickListener(v -> {
            if (selectedTeam1.isEmpty() || selectedTeam2.isEmpty()) {
                Toast.makeText(MatchActivity.this, "Select both teams", Toast.LENGTH_SHORT).show();
            } else if (selectedTeam1.equals(selectedTeam2)) {
                Toast.makeText(MatchActivity.this, "Teams must be different", Toast.LENGTH_SHORT).show();
            } else if (selectedDate.isEmpty() || selectedTime.isEmpty()) {
                Toast.makeText(MatchActivity.this, "Select date and time", Toast.LENGTH_SHORT).show();
            } else {
                String team1ScoreStr = team1ScoreInput.getText().toString().trim();
                String team2ScoreStr = team2ScoreInput.getText().toString().trim();
                Integer team1Score = team1ScoreStr.isEmpty() ? null : Integer.parseInt(team1ScoreStr);
                Integer team2Score = team2ScoreStr.isEmpty() ? null : Integer.parseInt(team2ScoreStr);

                int team1Id = dbHelper.getTeamIdByName(selectedTeam1);
                int team2Id = dbHelper.getTeamIdByName(selectedTeam2);
                if (team1Id != -1 && team2Id != -1) {
                    boolean isAdded = dbHelper.addMatch(team1Id, team2Id, selectedDate, selectedTime, team1Score, team2Score);
                    if (isAdded) {
                        Toast.makeText(MatchActivity.this, "Match scheduled", Toast.LENGTH_SHORT).show();
                        NotificationHelper.scheduleMatchNotification(this, (int) System.currentTimeMillis(),
                                selectedTeam1, selectedTeam2, selectedDate, selectedTime);
                        dateText.setText("");
                        timeText.setText("");
                        team1ScoreInput.setText("");
                        team2ScoreInput.setText("");
                        selectedDate = "";
                        selectedTime = "";
                        selectedTeam1 = "";
                        selectedTeam2 = "";
                        team1Spinner.setSelection(0);
                        team2Spinner.setSelection(0);
                        Log.d(TAG, "Match scheduled: " + selectedTeam1 + " vs " + selectedTeam2);
                    } else {
                        Toast.makeText(MatchActivity.this, "Failed to schedule match", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "Failed to schedule match");
                    }
                } else {
                    Toast.makeText(MatchActivity.this, "Team not found", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Team not found: Team1 ID=" + team1Id + ", Team2 ID=" + team2Id);
                }
            }
        });

        // View Matches button
        viewMatchesButton.setOnClickListener(v -> {
            try {
                List<String> matches = dbHelper.getAllMatches();
                if (matches.isEmpty()) {
                    matchListText.setText("No matches scheduled");
                } else {
                    StringBuilder matchList = new StringBuilder();
                    for (String match : matches) {
                        matchList.append(match).append("\n");
                    }
                    matchListText.setText(matchList.toString());
                }
                Log.d(TAG, "Displayed " + matches.size() + " matches");
            } catch (Exception e) {
                Log.e(TAG, "Error viewing matches: " + e.getMessage());
                Toast.makeText(MatchActivity.this, "Error viewing matches", Toast.LENGTH_SHORT).show();
            }
        });
    }
}