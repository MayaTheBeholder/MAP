package com.example.myhockyapp;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class MatchActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private Spinner team1Spinner, team2Spinner;
    private EditText dateInput, timeInput, scoreTeam1Input, scoreTeam2Input;
    private Button scheduleMatchButton, viewFixturesButton, viewHistoryButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_match);

        Toolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            toolbar.setTitle("");
        }

        dbHelper = new DatabaseHelper(this);
        team1Spinner = findViewById(R.id.team1_spinner);
        team2Spinner = findViewById(R.id.team2_spinner);
        dateInput = findViewById(R.id.date_input);
        timeInput = findViewById(R.id.time_input);
        scoreTeam1Input = findViewById(R.id.score_team1_input);
        scoreTeam2Input = findViewById(R.id.score_team2_input);
        scheduleMatchButton = findViewById(R.id.schedule_match_button);
        viewFixturesButton = findViewById(R.id.view_fixtures_button);
        viewHistoryButton = findViewById(R.id.view_history_button);

        loadTeams();

        if (dateInput != null) {
            dateInput.setOnClickListener(v -> showDatePicker());
        }
        if (timeInput != null) {
            timeInput.setOnClickListener(v -> showTimePicker());
        }
        if (scheduleMatchButton != null) {
            scheduleMatchButton.setOnClickListener(v -> scheduleMatch());
        }
        if (viewFixturesButton != null) {
            viewFixturesButton.setOnClickListener(v -> {
                Intent intent = new Intent(MatchActivity.this, FixturesActivity.class);
                startActivity(intent);
            });
        }
        if (viewHistoryButton != null) {
            viewHistoryButton.setOnClickListener(v -> {
                Intent intent = new Intent(MatchActivity.this, MatchHistoryActivity.class);
                startActivity(intent);
            });
        }
    }

    private void loadTeams() {
        ArrayList<String> teams = new ArrayList<>();
        try {
            teams.addAll(dbHelper.getAllTeams());
        } catch (Exception e) {
            Toast.makeText(this, "Error loading teams", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

        if (team1Spinner != null && team2Spinner != null) {
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, teams);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            team1Spinner.setAdapter(adapter);
            team2Spinner.setAdapter(adapter);
        }
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String date = String.format("%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay);
                    if (dateInput != null) {
                        dateInput.setText(date);
                    }
                }, year, month, day);
        datePickerDialog.show();
    }

    private void showTimePicker() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (view, selectedHour, selectedMinute) -> {
                    String time = String.format("%02d:%02d", selectedHour, selectedMinute);
                    if (timeInput != null) {
                        timeInput.setText(time);
                    }
                }, hour, minute, true);
        timePickerDialog.show();
    }

    private void scheduleMatch() {
        if (team1Spinner == null || team2Spinner == null || dateInput == null || timeInput == null ||
                scoreTeam1Input == null || scoreTeam2Input == null) {
            Toast.makeText(this, "UI components not initialized", Toast.LENGTH_SHORT).show();
            return;
        }

        String team1 = team1Spinner.getSelectedItem() != null ? team1Spinner.getSelectedItem().toString() : "";
        String team2 = team2Spinner.getSelectedItem() != null ? team2Spinner.getSelectedItem().toString() : "";
        String date = dateInput.getText().toString().trim();
        String time = timeInput.getText().toString().trim();
        String scoreTeam1Str = scoreTeam1Input.getText().toString().trim();
        String scoreTeam2Str = scoreTeam2Input.getText().toString().trim();

        if (team1.isEmpty() || team2.isEmpty() || date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int team1Id = dbHelper.getTeamId(team1);
        int team2Id = dbHelper.getTeamId(team2);
        if (team1Id == -1 || team2Id == -1) {
            Toast.makeText(this, "Invalid team selected", Toast.LENGTH_SHORT).show();
            return;
        }

        int scoreTeam1 = scoreTeam1Str.isEmpty() ? 0 : Integer.parseInt(scoreTeam1Str);
        int scoreTeam2 = scoreTeam2Str.isEmpty() ? 0 : Integer.parseInt(scoreTeam2Str);

        boolean success = dbHelper.addMatch(team1Id, team2Id, date, time, scoreTeam1, scoreTeam2);
        if (success) {
            Toast.makeText(this, "Match scheduled", Toast.LENGTH_SHORT).show();
            scheduleNotification(team1Id, team1, team2, date, time);
            clearInputs();
        } else {
            Toast.makeText(this, "Failed to schedule match", Toast.LENGTH_SHORT).show();
        }
    }

    private void scheduleNotification(long matchId, String team1, String team2, String date, String time) {
        try {
            Calendar matchTime = Calendar.getInstance();
            String[] dateParts = date.split("-");
            String[] timeParts = time.split(":");
            matchTime.set(Integer.parseInt(dateParts[0]), Integer.parseInt(dateParts[1]) - 1,
                    Integer.parseInt(dateParts[2]), Integer.parseInt(timeParts[0]), Integer.parseInt(timeParts[1]), 0);

            long delay = matchTime.getTimeInMillis() - System.currentTimeMillis() - 30 * 1000; // 30 seconds before
            if (delay < 0) delay = 0;

            Data inputData = new Data.Builder()
                    .putLong("match_id", matchId)
                    .putString("team1", team1)
                    .putString("team2", team2)
                    .build();

            OneTimeWorkRequest notificationWork = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                    .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                    .setInputData(inputData)
                    .build();

            WorkManager.getInstance(this).enqueue(notificationWork);
        } catch (Exception e) {
            Toast.makeText(this, "Error scheduling notification", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearInputs() {
        if (dateInput != null) dateInput.setText("");
        if (timeInput != null) timeInput.setText("");
        if (scoreTeam1Input != null) scoreTeam1Input.setText("");
        if (scoreTeam2Input != null) scoreTeam2Input.setText("");
        if (team1Spinner != null) team1Spinner.setSelection(0);
        if (team2Spinner != null) team2Spinner.setSelection(0);
    }
}