package com.example.myhockyapp;

  import android.database.Cursor;
  import android.os.Bundle;
  import android.widget.ArrayAdapter;
  import android.widget.ListView;
  import androidx.appcompat.app.AppCompatActivity;
  import androidx.appcompat.widget.Toolbar;
  import java.util.ArrayList;

  public class MatchHistoryActivity extends AppCompatActivity {
      private DatabaseHelper dbHelper;
      private ListView historyList;

      @Override
      protected void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          setContentView(R.layout.activity_match_history);

          Toolbar toolbar = findViewById(R.id.toolbar);
          setSupportActionBar(toolbar);
          toolbar.setTitle("");

          dbHelper = new DatabaseHelper(this);
          historyList = findViewById(R.id.history_list);

          loadHistory();
      }

      private void loadHistory() {
          ArrayList<String> history = new ArrayList<>();
          Cursor cursor = dbHelper.getMatchHistory();
          if (cursor.moveToFirst()) {
              do {
                  int matchId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                  String team1Name = cursor.getString(cursor.getColumnIndexOrThrow("team1_name"));
                  String team2Name = cursor.getString(cursor.getColumnIndexOrThrow("team2_name"));
                  String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                  String time = cursor.getString(cursor.getColumnIndexOrThrow("time"));
                  int scoreTeam1 = cursor.getInt(cursor.getColumnIndexOrThrow("score_team1"));
                  int scoreTeam2 = cursor.getInt(cursor.getColumnIndexOrThrow("score_team2"));
                  history.add("Match ID: " + matchId + "\n" +
                          team1Name + " " + scoreTeam1 + " vs " + scoreTeam2 + " " + team2Name + "\n" +
                          "Date: " + date + " " + time);
              } while (cursor.moveToNext());
          }
          cursor.close();

          ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                  android.R.layout.simple_list_item_1, history);
          historyList.setAdapter(adapter);
      }
  }