package com.example.myhockyapp;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private static final int NOTIFICATION_PERMISSION_CODE = 100;
    private EditText teamNameInput;
    private Button addTeamButton, viewTeamsButton, managePlayersButton, scheduleMatchesButton, viewStandingsButton;
    private TextView teamListText;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Request notification permission for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.POST_NOTIFICATIONS},
                        NOTIFICATION_PERMISSION_CODE);
            }
        }

        // Initialize notification channel
        NotificationHelper.createNotificationChannel(this);

        // Initialize UI components
        try {
            teamNameInput = findViewById(R.id.team_name_input);
            addTeamButton = findViewById(R.id.add_team_button);
            viewTeamsButton = findViewById(R.id.view_teams_button);
            managePlayersButton = findViewById(R.id.manage_players_button);
            scheduleMatchesButton = findViewById(R.id.schedule_matches_button);
            viewStandingsButton = findViewById(R.id.view_standings_button);
            teamListText = findViewById(R.id.team_list_text);
        } catch (Exception e) {
            Log.e(TAG, "Error initializing UI components: " + e.getMessage());
            Toast.makeText(this, "UI initialization failed", Toast.LENGTH_LONG).show();
            return;
        }

        // Initialize database
        try {
            dbHelper = new DatabaseHelper(this);
        } catch (Exception e) {
            Log.e(TAG, "Error initializing database: " + e.getMessage());
            Toast.makeText(this, "Database initialization failed", Toast.LENGTH_LONG).show();
            return;
        }

        // Add Team button click listener
        addTeamButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String teamName = teamNameInput.getText().toString().trim();
                if (teamName.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter team name", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        boolean isAdded = dbHelper.addTeam(teamName);
                        if (isAdded) {
                            Toast.makeText(MainActivity.this, "Team added", Toast.LENGTH_SHORT).show();
                            teamNameInput.setText("");
                        } else {
                            Toast.makeText(MainActivity.this, "Failed to add team", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error adding team: " + e.getMessage());
                        Toast.makeText(MainActivity.this, "Error adding team: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        // View Teams button click listener
        viewTeamsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    List<String> teams = dbHelper.getAllTeams();
                    if (teams.isEmpty()) {
                        teamListText.setText("No teams available");
                    } else {
                        StringBuilder teamList = new StringBuilder();
                        for (String team : teams) {
                            teamList.append(team).append("\n");
                        }
                        teamListText.setText(teamList.toString());
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error viewing teams: " + e.getMessage());
                    Toast.makeText(MainActivity.this, "Error viewing teams", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Manage Players button click listener
        managePlayersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PlayerActivity.class);
                startActivity(intent);
            }
        });

        // Schedule Matches button click listener
        scheduleMatchesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MatchActivity.class);
                startActivity(intent);
            }
        });

        // View Standings button click listener
        viewStandingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, StandingsActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Notification permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Notification permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}