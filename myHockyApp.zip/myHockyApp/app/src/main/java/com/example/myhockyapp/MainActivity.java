package com.example.myhockyapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {
    private EditText teamNameInput;
    private Button addTeamButton, viewStandingsButton, viewMatchesButton, viewPlayersButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle(""); // Clear title

        teamNameInput = findViewById(R.id.team_name_input);
        addTeamButton = findViewById(R.id.add_team_button);
        viewStandingsButton = findViewById(R.id.view_standings_button);
        viewMatchesButton = findViewById(R.id.view_matches_button);
        viewPlayersButton = findViewById(R.id.view_players_button);
        dbHelper = new DatabaseHelper(this);

        addTeamButton.setOnClickListener(v -> {
            String teamName = teamNameInput.getText().toString().trim();
            if (!teamName.isEmpty()) {
                if (dbHelper.addTeam(teamName)) {
                    teamNameInput.setText("");
                    Toast.makeText(this, "Team added", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Failed to add team", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Enter team name", Toast.LENGTH_SHORT).show();
            }
        });

        viewStandingsButton.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(MainActivity.this, StandingsActivity.class);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "Error opening standings", Toast.LENGTH_SHORT).show();
            }
        });

        viewMatchesButton.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(MainActivity.this, MatchActivity.class);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "Error opening matches", Toast.LENGTH_SHORT).show();
            }
        });

        viewPlayersButton.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(MainActivity.this, PlayerActivity.class);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "Error opening players", Toast.LENGTH_SHORT).show();
            }
        });
    }
}