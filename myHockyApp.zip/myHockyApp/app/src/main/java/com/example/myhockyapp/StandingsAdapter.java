package com.example.myhockyapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class StandingsAdapter extends RecyclerView.Adapter<StandingsAdapter.StandingViewHolder> {
    private List<DatabaseHelper.TeamStanding> standings;

    public StandingsAdapter(List<DatabaseHelper.TeamStanding> standings) {
        this.standings = standings;
    }

    @Override
    public StandingViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.standing_item, parent, false);
        return new StandingViewHolder(view);
    }

    @Override
    public void onBindViewHolder(StandingViewHolder holder, int position) {
        DatabaseHelper.TeamStanding standing = standings.get(position);
        holder.rankText.setText(String.valueOf(position + 1));
        holder.teamNameText.setText(standing.teamName);
        holder.matchesPlayedText.setText(String.valueOf(standing.matchesPlayed));
        holder.winsText.setText(String.valueOf(standing.wins));
        holder.drawsText.setText(String.valueOf(standing.draws));
        holder.lossesText.setText(String.valueOf(standing.losses));
        holder.goalsScoredText.setText(String.valueOf(standing.goalsScored));
        holder.goalsConcededText.setText(String.valueOf(standing.goalsConceded));
        holder.pointsText.setText(String.valueOf(standing.points));
    }

    @Override
    public int getItemCount() {
        return standings.size();
    }

    static class StandingViewHolder extends RecyclerView.ViewHolder {
        TextView rankText, teamNameText, matchesPlayedText, winsText, drawsText,
                lossesText, goalsScoredText, goalsConcededText, pointsText;

        StandingViewHolder(View itemView) {
            super(itemView);
            rankText = itemView.findViewById(R.id.rank_text);
            teamNameText = itemView.findViewById(R.id.team_name_text);
            matchesPlayedText = itemView.findViewById(R.id.matches_played_text);
            winsText = itemView.findViewById(R.id.wins_text);
            drawsText = itemView.findViewById(R.id.draws_text);
            lossesText = itemView.findViewById(R.id.losses_text);
            goalsScoredText = itemView.findViewById(R.id.goals_scored_text);
            goalsConcededText = itemView.findViewById(R.id.goals_conceded_text);
            pointsText = itemView.findViewById(R.id.points_text);
        }
    }
}