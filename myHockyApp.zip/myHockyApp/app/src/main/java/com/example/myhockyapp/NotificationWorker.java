package com.example.myhockyapp;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class NotificationWorker extends Worker {
    public NotificationWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        int matchId = getInputData().getInt("matchId", 0);
        String team1 = getInputData().getString("team1");
        String team2 = getInputData().getString("team2");
        String date = getInputData().getString("date");
        String time = getInputData().getString("time");

        NotificationHelper.showNotification(getApplicationContext(), matchId, team1, team2, date, time);
        return Result.success();
    }
}